import React, { Component } from 'react'

export default class About extends Component {
  render() {
    return (
        <div>
            <h2>About Page</h2>
            <p>Let's Share our contact info </p>
      </div>
    )
  }
}
