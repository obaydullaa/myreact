import React, { Component } from 'react'

export default class Home extends Component {
  render() {
    return (
      <div>
        <h2>It is your Home Page</h2>
        <p>Let's Share our contact info </p>
      </div>
    )
  }
}
